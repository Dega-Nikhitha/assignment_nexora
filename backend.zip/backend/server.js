const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DB_FILE = path.join(__dirname, 'db.sqlite');
const dbExists = fs.existsSync(DB_FILE);
const db = new sqlite3.Database(DB_FILE);

if (!dbExists) {
  db.serialize(() => {
    db.run(`CREATE TABLE products(id TEXT PRIMARY KEY, name TEXT, price INTEGER)`);
    db.run(`CREATE TABLE cart(id TEXT PRIMARY KEY, productId TEXT, qty INTEGER)`);
    const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/seedProducts.json')));
    const stmt = db.prepare(`INSERT INTO products(id,name,price) VALUES(?,?,?)`);
    for (const p of products) stmt.run(p.id, p.name, p.price);
    stmt.finalize();
  });
}

app.get('/api/products', (req, res) => {
  db.all('SELECT * FROM products', (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(rows);
  });
});

app.post('/api/cart', (req, res) => {
  const { productId, qty } = req.body;
  if (!productId || !qty || qty <= 0) return res.status(400).json({ error: 'Invalid payload' });
  const id = uuidv4();
  db.run('INSERT INTO cart(id,productId,qty) VALUES(?,?,?)', [id, productId, qty], function (err) {
    if (err) return res.status(500).json({ error: 'DB insert failed' });
    res.status(201).json({ id, productId, qty });
  });
});

app.delete('/api/cart/:id', (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM cart WHERE id = ?', [id], function (err) {
    if (err) return res.status(500).json({ error: 'DB delete failed' });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ success: true });
  });
});

app.put('/api/cart/:id', (req, res) => {
  const { id } = req.params;
  const { qty } = req.body;
  if (!qty || qty <= 0) return res.status(400).json({ error: 'Invalid qty' });
  db.run('UPDATE cart SET qty = ? WHERE id = ?', [qty, id], function (err) {
    if (err) return res.status(500).json({ error: 'DB update failed' });
    if (this.changes === 0) return res.status(404).json({ error: 'Not found' });
    res.json({ success: true });
  });
});

app.get('/api/cart', (req, res) => {
  const sql = `SELECT c.id as cartId, c.productId, c.qty, p.name, p.price
               FROM cart c JOIN products p ON c.productId = p.id`;
  db.all(sql, (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    const items = rows.map(r => ({ id: r.cartId, productId: r.productId, name: r.name, price: r.price, qty: r.qty }));
    const total = items.reduce((s, it) => s + it.price * it.qty, 0);
    res.json({ items, total });
  });
});

app.post('/api/checkout', (req, res) => {
  const { cartItems, name, email } = req.body;
  if (!Array.isArray(cartItems) || cartItems.length === 0) return res.status(400).json({ error: 'Empty cart' });
  const placeholders = cartItems.map(() => '?').join(',');
  const productIds = cartItems.map(ci => ci.productId);
  db.all(`SELECT id, price, name FROM products WHERE id IN (${placeholders})`, productIds, (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    const priceById = Object.fromEntries(rows.map(r => [r.id, { price: r.price, name: r.name }]));
    let total = 0;
    for (const ci of cartItems) {
      const p = priceById[ci.productId];
      if (!p) return res.status(400).json({ error: `Invalid product ${ci.productId}` });
      total += p.price * ci.qty;
    }
    const detailedItems = cartItems.map(ci => ({
  id: ci.id,
  productId: ci.productId,
  name: priceById[ci.productId]?.name || 'Unknown Product',
  qty: ci.qty,
  price: priceById[ci.productId]?.price || 0
}));

const receipt = {
  id: uuidv4(),
  name: name || 'Guest',
  email,
  items: detailedItems,
  total,
  timestamp: new Date().toISOString()
};

    const cartIds = cartItems.map(ci => ci.id);
    if (cartIds.length) {
      const placeholders2 = cartIds.map(() => '?').join(',');
      db.run(`DELETE FROM cart WHERE id IN (${placeholders2})`, cartIds, () => res.json({ receipt }));
    } else res.json({ receipt });
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
